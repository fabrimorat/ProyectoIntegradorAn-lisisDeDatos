
##python.exe .\transformar\trans.py
import mysql.connector
from mysql.connector import Error
import pandas as pd
from datetime import datetime

def transformar_category(categories):
    try:
        categories['now'] = datetime.now()
        return categories
    except:
        print_exc()
    finally:
        pass

try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )
    
    if conexion.is_connected():
        print("Conexión exitosa")
        
        
        
    # Ejemplo de uso de la función transformar:
    data = {'categories': ['organizacion1', 'organizacion2', 'organizacion3']}
    df = pd.DataFrame(data)
    transformed_df = transformar_category(df)
    print(transformed_df)
    
except Error as ex:
    print("Error durante la conexión:", ex)
