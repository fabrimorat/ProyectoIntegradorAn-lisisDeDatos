
### SOLO CON MODULO FAKER
from mysql.connector import Error
from faker import Faker
import mysql.connector

# Crear una instancia de Faker
faker = Faker()

try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )

    if conexion.is_connected():
        print("Conexión Exitosa")

        # Obtener un cursor para ejecutar consultas
        cursor = conexion.cursor()

        # Obtener el último idKits insertado
        cursor.execute("SELECT MAX(idKits) FROM Kits")
        result = cursor.fetchone()
        last_id = result[0] if result[0] else 0

        # Generar datos falsos y ejecutar una consulta de inserción
        for _ in range(10):  # Cambia el número de registros que deseas insertar
            last_id += 1
            nombre = faker.word()
            cantidad = faker.random_int(min=1, max=100)

            consulta = "INSERT INTO Kits (idKits, nombre, cantidad) VALUES (%s, %s, %s)"
            datos = (last_id, nombre, cantidad)
            cursor.execute(consulta, datos)

        # Confirmar los cambios
        conexion.commit()

        # Cerrar el cursor y la conexión
        cursor.close()
        conexion.close()

except Error as ex:
    print("Error durante la conexión:", ex)
    
    