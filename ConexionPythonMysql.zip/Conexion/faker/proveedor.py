
    
    
#########CON PYTHON
   
from mysql.connector import Error
from faker import Faker
import pandas as pd
import mysql.connector

# Crear una instancia de Faker
faker = Faker()

try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )

    if conexion.is_connected():
        print("Conexión Exitosa")

        # Obtener un cursor para ejecutar consultas
        cursor = conexion.cursor()

        # Generar datos falsos y almacenarlos en una lista
        data = []
        for _ in range(10):  # Cambia el número de registros que deseas generar
            idProveedor = faker.random_int(min=1, max=100)
            idOrganizacion = faker.random_int(min=1, max=100)
            nombre = faker.word()
            
            data.append((idModelo, nombre))

        # Insertar los datos en la tabla "Kits"
        consulta = "INSERT INTO Proveedor (idProveedor,idOrganizacion,nombre) VALUES (%s, %s)"
        cursor.executemany(consulta, data)

        # Confirmar los cambios
        conexion.commit()

        # Obtener los datos de la tabla "Kits" utilizando Pandas
        consulta_select = "SELECT * FROM Proveedor"
        cursor.execute(consulta_select)
        columnas = [desc[0] for desc in cursor.description]
        filas = cursor.fetchall()
        df = pd.DataFrame(filas, columns=columnas)
        print(df)

        # Cerrar el cursor y la conexión
        cursor.close()
        conexion.close()

except Error as ex:
    print("Error durante la conexión:", ex)
