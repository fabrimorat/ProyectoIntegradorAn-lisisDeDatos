import mysql.connector
from mysql.connector import Error
import pandas as pd

try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )

    if conexion.is_connected():
        print("Conexión Exitosa")

        

        # Leer el archivo CSV y almacenar los datos en un DataFrame(python.exe .\extraccion\ex_traer.py)
        file = 'C:/tpm/vms/organizacion.csv'
        df_csv = pd.read_csv(file)

        # Imprimir los primeros registros del archivo CSV
        print(df_csv.head())

        

except Error as ex:
    print("Error durante la conexión:", ex)
