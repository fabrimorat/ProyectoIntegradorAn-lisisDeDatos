#python.exe .\persistir\per.py
import mysql.connector
from mysql.connector import Error
import pandas as pd

def copiar_datos_organizacion():
    try:
        host = '10.10.10.2'
        port = '3306'
        user = 'admin'
        password = 'Password12345@'
        db = 'proyecto'

        conexion = mysql.connector.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            db=db
        )

        if conexion.is_connected():
            print("Conexión exitosa")
            cursor = conexion.cursor()

            # Obtener los datos de la tabla organizacion
            cursor.execute("SELECT * FROM Organizacion")
            resultados = cursor.fetchall()

            # Crear DataFrame con los datos de organizacion
            df_organizacion = pd.DataFrame(resultados, columns=['idOrganizacion', 'nombre'])

            # Crear la tabla countries si no existe
            crear_tabla = """
            CREATE TABLE IF NOT EXISTS countries (
                idOrganizacion smallint PRIMARY KEY AUTO_INCREMENT,
                nombre VARCHAR(50)Not null
            )
            """
            cursor.execute(crear_tabla)
            

            # Insertar los datos de organizacion en la tabla countries
            for index, row in df_organizacion.iterrows():
                insertar_datos = """
                INSERT INTO countries (idOrganizacion, nombre)
                VALUES (%s, %s)
                """
                datos = (row['idOrganizacion'], row['nombre'])
                cursor.execute(insertar_datos, datos)
            df_organizacion.to_sql('countries', conexion, if_exists='append', index=False)

            conexion.commit()
            print("Datos copiados correctamente de organizacion a countries")
            cursor.close()
            

    except Error as ex:
        print("Error durante la conexión:", ex)

    finally:
        if conexion.is_connected():
            conexion.close()
            print("Conexión cerrada")

# Ejemplo de uso
copiar_datos_organizacion()
