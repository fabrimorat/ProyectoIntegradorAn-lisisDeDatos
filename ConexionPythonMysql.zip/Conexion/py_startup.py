
import mysql.connector
import pandas as pd

from mysql.connector import Error
from extraccion.ex_traer import extraer


try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )
    
    if conexion.is_connected():
        print("Conexión Exitosa")
        
        # Realizar la consulta/EXTRACCION DE DATOS
        consulta = "SELECT * FROM Organizacion"
        df = pd.read_sql_query(consulta, conexion)
        print(df)
        
        
    
        
except Error as ex:
    print("Error durante la conexión:", ex)
