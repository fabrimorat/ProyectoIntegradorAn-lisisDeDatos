import mysql.connector

from mysql.connector import Error

try:
    conexion = mysql.connector.connect(
        host='10.10.10.2',
        port='3306',
        user='admin',
        password='Password12345@',
        db='proyecto'
    )
    
    if conexion.is_connected():
        print("Conexión Exitosa")
        
        # Crear la tabla
        cursor = conexion.cursor()
        crear_tabla = "CREATE TABLE Ingreso (idIngreso INT PRIMARY KEY,fecha date NOT NULL)"
        cursor.execute(crear_tabla)
        
        # Confirmar los cambios
        conexion.commit()
        
        # Cerrar el cursor y la conexión
        cursor.close()
        conexion.close()
        
        print("Tabla creada exitosamente")
    
except Error as ex:
    print("Error durante la conexión:", ex)
